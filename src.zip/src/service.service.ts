import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  getpage1json='assets/taskjsonfile/page1.json'
  getpage2json='assets/taskjsonfile/page2.json'
  getpage3json='assets/taskjsonfile/page3.json'
  getpage4json='assets/taskjsonfile/page4.json'
  constructor(private http:HttpClient) { }

  getpage1(){
    debugger
    return this.http.get<any>(this.getpage1json)
  }
  getpage2(){
    debugger
    return this.http.get<any>(this.getpage2json)
  }
  getpage3(){
    debugger
    return this.http.get<any>(this.getpage3json)
  }
  getpage4(){
    debugger
    return this.http.get<any>(this.getpage4json)
  }

}
