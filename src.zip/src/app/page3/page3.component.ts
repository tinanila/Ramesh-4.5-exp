import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/service.service';

@Component({
  selector: 'app-page3',
  templateUrl: './page3.component.html',
  styleUrls: ['./page3.component.css'],
  
})
export class Page3Component implements OnInit {
  response: any;
  week: any;
  basicData:any
  basicOptions:any

  constructor(private service:ServiceService) { }

  ngOnInit(): void {
    this.getchart2method()
  }
  
  getchart2method()
  {

    this.service.getpage3().subscribe(res=>{
      debugger
      this.response = res
      this.week=this.response.values[0].data,
      this.basicData = {
        labels: this.response.label,
        datasets: [
            {
                label: 'Week',
                data: this.week,
                fill: false,
                borderColor: '#ff69b4'
            
            },
          ]
          }
           

          this.basicOptions = {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true, // Start Y-axis at zero
                title: {
                  display: true,
                  text: 'Attendence',
               
                },
                ticks: {
                  color: 'black' // Y-axis ticks color
                }
              },
              
            },
            plugins: {
              legend: {
                labels: {
                  color: 'black' // Legend text color
                }
              },
             
            }
          };
    })
   
  }
}
