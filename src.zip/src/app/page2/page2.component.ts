import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/service.service';

@Component({
  selector: 'app-page2',
  templateUrl: './page2.component.html',
  styleUrls: ['./page2.component.css']
})
export class Page2Component implements OnInit {
response:any;
pending:any;
completed:any;
  basicData: any
  basicOptions: any
  constructor(private service:ServiceService) { }

  ngOnInit(): void {
    debugger
    this.getchartmethod()
  }
  getchartmethod()
  {
    debugger
this.service.getpage2().subscribe((res)=>{
  debugger
  this.response = res
  this.pending=this.response.values[0].data,
  this.completed=this.response.values[1].data,

  this.basicData = {
    labels: this.response.label,
    datasets: [
        {
            label: 'Completed',
            data: this.completed, 
            backgroundColor:'rgba(0, 100, 0, 0.8)',
            borderWidth: 1
        },

        {
          label: 'Pending',
          data: this.pending,
          backgroundColor:'rgba(64, 64, 64, 0.8)',
          borderWidth: 1
      },
   
    ]
};

this.basicOptions = {
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    y: {
      beginAtZero: true, 
      title: {
        display: false,
        text: 'Values',
     
      },
      ticks: {
        color: 'black' 
      }
    },
    
  },
  plugins: {
    legend: {
      labels: {
        color: 'black' 
      }
    },
   
  }
};

// this.basicOptions = {
//   responsive: false,
//   maintainAspectRatio: false, 
//     plugins: {
//         legend: {
//             labels: {
//                 color: "black"
//             }
//         },
        
        
//     },
// };
})



  }
}
