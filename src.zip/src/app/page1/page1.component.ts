import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/service.service';

@Component({
  selector: 'app-page1',
  templateUrl: './page1.component.html',
  styleUrls: ['./page1.component.css']
})
export class Page1Component implements OnInit {
  sidebar: any;

  constructor(private service:ServiceService) { }

  ngOnInit(): void {
    debugger
this.service.getpage1().subscribe((res)=>{
  debugger
  this.sidebar=res

})
  }

}
